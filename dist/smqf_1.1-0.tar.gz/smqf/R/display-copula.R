#' Display a Bivariate Copula Surface
#'
#' Evaluates and displays a bivariate copula function (typically a PDF or CDF)
#' on a 2D grid, producing a static 3D surface via base R's \code{persp()}.
#'
#' @param my_copula A function that takes a numeric vector \code{c(u1, u2)} as input
#'   and returns a scalar value (e.g., a copula PDF or CDF).
#' @param grid_1,grid_2 Numeric vectors defining the evaluation grid for
#'   \eqn{u_1} and \eqn{u_2} in the interval \eqn{[0,1]}.
#' @param plot Logical; if \code{TRUE} (the default), a 3D surface is drawn via
#'   \code{graphics::persp()}. If \code{FALSE}, no graphics device is opened and
#'   only the evaluated matrix is returned (useful for testing or
#'   non-interactive use).
#'
#' @return Invisibly returns the matrix of evaluated copula values
#'   \code{f_U}, with rows corresponding to \code{grid_1} and columns to \code{grid_2}.
#'
#' @details
#' This function provides a simple way to visualize the surface of a bivariate
#' copula (e.g., Clayton, Gumbel, Gaussian). The copula function should accept a
#' vector of two uniform values \eqn{(u_1,u_2)} and return its density or CDF
#' value.
#'
#' @examples
#' # Example: Display the Clayton copula PDF surface
#' grid <- seq(0.05, 0.95, length.out = 25)
#' f_display_copula(
#'   my_copula = function(u) f_clayton_copula_2d_pdf(u, theta = 2),
#'   grid_1 = grid,
#'   grid_2 = grid
#' )
#'
#' @importFrom graphics persp
#' @export
f_display_copula <- function(my_copula, grid_1, grid_2, plot = TRUE) {

  ## --- input validation ---
  if (!is.function(my_copula))
    stop("'my_copula' must be a function.", call. = FALSE)
  if (!is.numeric(grid_1) || length(grid_1) == 0L)
    stop("'grid_1' must be a non-empty numeric vector.", call. = FALSE)
  if (!is.numeric(grid_2) || length(grid_2) == 0L)
    stop("'grid_2' must be a non-empty numeric vector.", call. = FALSE)
  if (!is.logical(plot) || length(plot) != 1L || is.na(plot))
    stop("'plot' must be a single logical value (TRUE or FALSE).", call. = FALSE)
  ## --- end validation ---

  n1 <- length(grid_1)
  n2 <- length(grid_2)

  f_U <- matrix(NA, n1, n2)
  for (j in seq_len(n1)) {
    for (k in seq_len(n2)) {
      u <- c(grid_1[j], grid_2[k])
      f_U[j, k] <- my_copula(u)
    }
  }

  if (plot) {
    graphics::persp(
      x = grid_1,
      y = grid_2,
      z = f_U,
      xlab = "U_1",
      ylab = "U_2",
      zlab = "Pdf",
      theta = 30,
      r = 20,
      col = "yellow",
      ticktype = "detailed",
      nticks = 4,
      expand = 0.5
    )
  }

  invisible(f_U)
}
